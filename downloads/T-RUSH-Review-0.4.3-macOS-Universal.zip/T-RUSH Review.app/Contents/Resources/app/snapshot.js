window.REVIEW_SNAPSHOT ||= {"spreadsheetId": "", "url": "", "title": "", "capturedAt": "", "sheets": []};
