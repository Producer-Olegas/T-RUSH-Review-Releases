(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./vendor/text-edits.js'):root.TitleFlowTextEdits);if(typeof module==='object'&&module.exports)module.exports=api;root.ReviewCore=api;})(typeof window==='undefined'?globalThis:window,function(Text){
  'use strict';
  const str=v=>String(v??'');
  const column=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
  const address=(r,c)=>column(c)+(r+1);
  const textField=h=>/^(?:(?:title|name|sur|work|post)(?:_|\d|$)|cur_(?:name|post)|en_(?:name|work|post))/.test(h.toLowerCase())||/^(название|текст|имя|фамилия|должность|тема)$/i.test(h);
  function defaults(sheet){
    let header=sheet.rows.slice(0,15).findIndex(row=>row.some(c=>str(c.v).trim().toLowerCase()==='output'));
    if(header<0)header=sheet.rows.slice(0,15).findIndex(row=>row.some(c=>textField(str(c.v).trim())));
    if(header<0)header=0;
    const headers=(sheet.rows[header]||[]).map(c=>str(c.v).trim());
    return {header,idColumn:headers.findIndex(h=>h.toLowerCase()==='output'),idPosition:'prefix',fields:headers.flatMap((h,c)=>textField(h)?[c]:[]),required:[]};
  }
  function idOf(value,position='prefix'){
    const text=str(value).trim();const m=position==='suffix'?text.match(/(?:^|_)(\d{3,})$/):text.match(/^(\d{3,})(?=_|$)/);
    return m&&Number(m[1])>0?m[1]:null;
  }
  const clean=value=>str(value).split(/(\r\n|\r|\n)/).map((s,i)=>i%2?s:Text.clean(s)).join('');
  function schema(sheet,config){
    const cfg={...defaults(sheet),...config};const headers=(sheet.rows[cfg.header]||[]).map(c=>str(c.v).trim());
    const fields=[...new Set(cfg.fields)].filter(c=>Number.isInteger(c)&&c>=0&&c<headers.length&&c!==cfg.idColumn&&headers[c]&&!/^(output|number)$/i.test(headers[c])).sort((a,b)=>a-b);
    return {...cfg,headers,fields,required:cfg.required.filter(c=>fields.includes(c))};
  }
  function completeOutput(value){const s=str(value).trim();return /^\d{3,}_/.test(s)&&s.slice(s.lastIndexOf('_')+1).trim().length>0;}
  function records(sheet,config){
    const cfg=schema(sheet,config);if(cfg.idColumn<0)return {cfg,records:[],reason:'no-id'};
    const start=sheet.rows.findIndex((row,r)=>r>cfg.header&&idOf(row[cfg.idColumn]?.v,cfg.idPosition)==='001');
    if(start<0)return {cfg,records:[],reason:'no-start'};
    const rows=[];for(let r=start;r<sheet.rows.length;r++){
      const row=sheet.rows[r]||[],id=idOf(row[cfg.idColumn]?.v,cfg.idPosition);
      if(!id||cfg.idPosition==='prefix'&&!completeOutput(row[cfg.idColumn]?.v)||!defaults(sheet).fields.some(c=>str(row[c]?.v).trim()))continue;
      rows.push({row:r,id,output:str(row[cfg.idColumn]?.v)});
    }
    const counts=new Map();rows.forEach(r=>counts.set(r.id,(counts.get(r.id)||0)+1));rows.forEach(r=>r.duplicate=counts.get(r.id)>1);
    return {cfg,records:rows,reason:''};
  }
  function ranges(text,regex){return [...text.matchAll(regex)].map(m=>[m.index,m.index+m[0].length]);}
  function issues(value){
    const s=str(value),out=Text.issues(s).map(i=>({...i,level:'warning'}));
    if(clean(s)!==s)out.unshift({code:'spaces',ru:'Лишние обычные пробелы.',en:'Extra ordinary spaces.',level:'warning'});
    if(/\u00a0/.test(s))out.push({code:'nbsp',ru:'Неразрывный пробел — проверьте, нужен ли он.',en:'Non-breaking space — check whether it is intentional.',level:'warning'});
    const rx={spaces:/^ +| +$| {2,}/gm,nbsp:/\u00a0/g,invisible:/[\t\u200b-\u200d\ufeff]/g,mixed:/[A-Za-zА-Яа-яЁё]+/g,quotes:/[«»“”"]/g,brackets:/[()[\]{}]/g,trailing:/[,;](?=\s*$)/g,punctuation:/\.{4,}|,{2,}|;{2,}|(?<!\.)\.{2}(?!\.)/g,spacing:/ +[,.;:!?)\]}»]|[(\[{«] +/g,repeated:/[A-Za-zА-Яа-яЁё]+/g};
    out.forEach(i=>{i.ranges=ranges(s,rx[i.code]||/$^/g);if(i.code==='mixed')i.ranges=i.ranges.filter(([a,b])=>/[A-Za-z]/.test(s.slice(a,b))&&/[А-Яа-яЁё]/.test(s.slice(a,b)));if(i.code==='repeated'){const words=[...s.matchAll(/[A-Za-zА-Яа-яЁё]+/g)];i.ranges=words.flatMap((m,n)=>n&&m[0].toLowerCase()===words[n-1][0].toLowerCase()?[[words[n-1].index,m.index+m[0].length]]:[]);}});
    return out;
  }
  function create(snapshot,saved={}){
    const patches=new Map(),versions=new Map(),recordCache=new Map();let revision=0,undoStack=[];
    const key=(s,r,c)=>[s,r,c].join(':');
    const findSheet=s=>snapshot.sheets.find(x=>String(x.id)===String(s));
    function cached(s,cfg){const k=JSON.stringify([s,cfg]);if(!recordCache.has(k)){const result=records(findSheet(s),cfg);result.rowSet=new Set(result.records.map(r=>r.row));recordCache.set(k,result);}return recordCache.get(k);}
    function writable(s,r,c,cfg){const sheet=findSheet(s);if(!sheet)return false;const result=cached(s,cfg),sc=result.cfg;const cell=sheet.rows[r]?.[c];return result.rowSet.has(r)&&sc.fields.includes(c)&&!cell?.f&&(!cell?.t||cell.t==='text');}
    function value(s,r,c){return patches.get(key(s,r,c))?.value??str(findSheet(s)?.rows[r]?.[c]?.v);}
    function set(s,r,c,next,cfg){if(!writable(s,r,c,cfg))return false;const k=key(s,r,c),base=str(findSheet(s).rows[r]?.[c]?.v);versions.set(k,++revision);if(str(next)===base)patches.delete(k);else patches.set(k,{sheetId:s,row:r,col:c,address:address(r,c),base,value:str(next)});return true;}
    function plan(s,cfg){const sheet=findSheet(s),result=records(sheet,cfg),out=[];for(const row of result.records)for(const c of result.cfg.fields){if(!writable(s,row.row,c,cfg))continue;const before=value(s,row.row,c),after=clean(before);if(before!==after)out.push({sheetId:s,row:row.row,col:c,before,after,id:row.id,field:result.cfg.headers[c],address:address(row.row,c)});}return out;}
    function auto(changes,cfg){const batch=[];for(const c of changes){if(value(c.sheetId,c.row,c.col)!==c.before)continue;const k=key(c.sheetId,c.row,c.col);if(set(c.sheetId,c.row,c.col,c.after,cfg))batch.push({...c,revision:versions.get(k)});}if(batch.length)undoStack.push(batch);return batch.length;}
    function undo(s,cfg){let n=undoStack.findLastIndex(b=>b[0]?.sheetId===s);if(n<0)return {restored:0,skipped:0};const batch=undoStack.splice(n,1)[0];let restored=0,skipped=0;for(const c of batch){const k=key(c.sheetId,c.row,c.col);if(versions.get(k)!==c.revision){skipped++;continue;}if(set(c.sheetId,c.row,c.col,c.before,cfg))restored++;else skipped++;}return {restored,skipped};}
    function rowIssues(s,row,cfg){const sheet=findSheet(s),sc=schema(sheet,cfg),out=[];if(row.duplicate)out.push({code:'duplicate',level:'error',ru:'Повтор ID в этом листе.',en:'Duplicate ID in this sheet.',col:null,ranges:[]});for(const c of sc.fields){const val=value(s,row.row,c);if(!val.trim())out.push({code:'empty',level:sc.required.includes(c)?'error':'info',col:c,ru:sc.required.includes(c)?'Обязательное поле пустое.':'Поле пустое.',en:sc.required.includes(c)?'Required field is empty.':'Empty field.',ranges:[]});else out.push(...issues(val).map(i=>({...i,col:c})));}return out;}
    function restore(configs){if(saved.spreadsheetId!==snapshot.spreadsheetId||saved.capturedAt!==snapshot.capturedAt)return 0;let n=0;for(const p of saved.patches||[]){const sheet=findSheet(p.sheetId);if(sheet&&p.base===str(sheet.rows[p.row]?.[p.col]?.v)&&typeof p.value==='string'&&set(p.sheetId,p.row,p.col,p.value,{...defaults(sheet),fields:[...new Set([...defaults(sheet).fields,p.col])]}))n++;}return n;}
    return {value,set,plan,auto,undo,rowIssues,writable,restore,canUndo:s=>undoStack.some(b=>b[0]?.sheetId===s),patches:()=>[...patches.values()],serialize:()=>({version:1,spreadsheetId:snapshot.spreadsheetId,capturedAt:snapshot.capturedAt,patches:[...patches.values()]})};
  }
  return {defaults,schema,records,idOf,completeOutput,clean,issues,create,column,address};
});
